package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Cache_table")
public class Cache_table {
	@Id
	@Column(name="user_id")
	private int userId;
	@Column(name="exam_id")
	private int examId;
	@Column(name="question_id")
	private int questionId;
	@Column(name="Ans_selected")
	private String ansSelected;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getExamId() {
		return examId;
	}
	public void setExamId(int examId) {
		this.examId = examId;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getAnsSelected() {
		return ansSelected;
	}
	public void setAnswerSelected(String ansSelected) {
		this.ansSelected = ansSelected;
	}

}
