package com.lti.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "exam")
public class Exam {
	@Id
	@Column(name = "exam_id")
	private int examId;

	@Column(name = "exam_name")
	private String examName;

	@Column(name = "exam_date")
	private String examDate;

	@Column(name = "start_time")
	private String startTime;

	@Column(name = "end_time")
	private String endTime;
	
	@OneToMany
	@JoinColumn(name="question_id")
	private List<Questions> questions;

	public Exam() {
		super();
	}

	public Exam(int examId, String examName, String examDate, String startTime, String endTime) {
		super();
		this.examId = examId;
		this.examName = examName;
		this.examDate = examDate;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public int getExamId() {
		return examId;
	}

	public void setExamId(int examId) {
		this.examId = examId;
	}

	public String getExamName() {
		return examName;
	}

	public void setExamName(String examName) {
		this.examName = examName;
	}

	public String getExamDate() {
		return examDate;
	}

	public void setExamDate(String examDate) {
		this.examDate = examDate;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}
